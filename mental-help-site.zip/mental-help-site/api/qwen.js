{\rtf1\ansi\ansicpg936\cocoartf2867
\cocoatextscaling0\cocoaplatform0{\fonttbl\f0\fnil\fcharset0 HelveticaNeue;}
{\colortbl;\red255\green255\blue255;\red0\green0\blue0;}
{\*\expandedcolortbl;;\cssrgb\c0\c0\c0;}
\paperw11900\paperh16840\margl1440\margr1440\vieww11520\viewh8400\viewkind0
\deftab720
\pard\pardeftab720\partightenfactor0

\f0\fs28 \cf0 \expnd0\expndtw0\kerning0
\outl0\strokewidth0 \strokec2 // \uc0\u25991 \u20214 \u36335 \u24452 \u65306 api/qwen.js\
\
import \{ createResponse \} from '@vercel/functions';\
\
const DASHSCOPE_API_KEY = process.env.DASHSCOPE_API_KEY; // \uc0\u20174 \u29615 \u22659 \u21464 \u37327 \u35835 \u21462 \
\
export default async function handler(request) \{\
  if (request.method !== 'POST') \{\
    return new Response(JSON.stringify(\{ error: '\uc0\u20165 \u25903 \u25345  POST \u35831 \u27714 ' \}), \{\
      status: 405,\
      headers: \{ 'Content-Type': 'application/json' \}\
    \});\
  \}\
\
  if (!DASHSCOPE_API_KEY) \{\
    return new Response(JSON.stringify(\{ error: '\uc0\u21518 \u31471 \u26410 \u37197 \u32622  API Key' \}), \{\
      status: 500,\
      headers: \{ 'Content-Type': 'application/json' \}\
    \});\
  \}\
\
  try \{\
    const \{ prompt \} = await request.json();\
\
    if (!prompt || typeof prompt !== 'string' || prompt.trim().length === 0) \{\
      return new Response(JSON.stringify(\{ error: '\uc0\u35831 \u36755 \u20837 \u26377 \u25928 \u38382 \u39064 ' \}), \{\
        status: 400,\
        headers: \{ 'Content-Type': 'application/json' \}\
      \});\
    \}\
\
    const response = await fetch('https://dashscope.aliyuncs.com/api/v1/services/aigc/text-generation/generation', \{\
      method: 'POST',\
      headers: \{\
        'Authorization': `Bearer $\{DASHSCOPE_API_KEY\}`,\
        'Content-Type': 'application/json'\
      \},\
      body: JSON.stringify(\{\
        model: 'qwen-turbo', // \uc0\u24555 \u36895 \u19988 \u20415 \u23452 \u65292 \u36866 \u21512 \u35797 \u29992 \
        input: \{\
          messages: [\
            \{\
              role: 'system',\
              content: '\uc0\u20320 \u26159 \u19968 \u20301 \u28201 \u21644 \u12289 \u19987 \u19994 \u30340 \u24515 \u29702 \u38506 \u20276 \u32773 \u12290 \u35831 \u25552 \u20379 \u20849 \u24773 \u12289 \u20542 \u21548 \u21644 \u19968 \u33324 \u24615 \u24314 \u35758 \u65292 \u36991 \u20813 \u35786 \u26029 \u12290 \u24378 \u35843 \'93\u22914 \u26377 \u20005 \u37325 \u22256 \u25200 \u65292 \u35831 \u23547 \u27714 \u19987 \u19994 \u24110 \u21161 \'94\u12290 \u22238 \u31572 \u31616 \u27905 \u12289 \u28201 \u26262 \u65292 \u19981 \u36229 \u36807 200\u23383 \u12290 '\
            \},\
            \{\
              role: 'user',\
              content: prompt.trim()\
            \}\
          ]\
        \},\
        parameters: \{\
          result_format: 'message'\
        \}\
      \})\
    \});\
\
    const data = await response.json();\
\
    if (!response.ok || !data.output?.choices?.[0]?.message?.content) \{\
      console.error('DashScope API error:', data);\
      return new Response(JSON.stringify(\{ error: 'AI \uc0\u26381 \u21153 \u26242 \u26102 \u19981 \u21487 \u29992 \u65292 \u35831 \u31245 \u21518 \u20877 \u35797 ' \}), \{\
        status: 500,\
        headers: \{ 'Content-Type': 'application/json' \}\
      \});\
    \}\
\
    const answer = data.output.choices[0].message.content;\
\
    return new Response(JSON.stringify(\{ answer \}), \{\
      headers: \{ 'Content-Type': 'application/json' \}\
    \});\
\
  \} catch (error) \{\
    console.error('Server error:', error);\
    return new Response(JSON.stringify(\{ error: '\uc0\u26381 \u21153 \u22120 \u20869 \u37096 \u38169 \u35823 ' \}), \{\
      status: 500,\
      headers: \{ 'Content-Type': 'application/json' \}\
    \});\
  \}\
\}}